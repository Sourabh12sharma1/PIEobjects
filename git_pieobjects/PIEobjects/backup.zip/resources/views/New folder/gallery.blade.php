@extends('layout.master')
@section('gallery')

    <!-- Inner page hedaing start -->
    <section class="irs-inner-page-heading irs-layer-black">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="irs-inner-heading">
                        <h2>gallery</h2>
                        <i class="icofont icofont-education"></i>
                        <p><a href="index-layout1.html">HOME</a> > <a href="#">Gallery</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Inner page hedaing end -->

    <!-- Teachers start -->
    <!-- <section class="irs-teachers-field"> -->
        <!-- <div class="container"> -->
            <!-- <div class="row animatedParent animateOnce"> -->
                <!-- <div class="col-md-3 col-sm-6"> -->
                    <!-- <div class="irs-teachers-col animated fadeInUpShort slow delay-250"> -->
                        <!-- <a href="teacher-single.html"><img src="images/teachers/1.jpg" alt=""> -->
                        <!-- </a> -->
                        <!-- <div class="irs-teachers-name"> -->
                            <!-- <h4><a href="teacher-single.html">Rosi Jqulin</a></h4> -->
                            <!-- <p>math teacher</p> -->
                        <!-- </div> -->
                        <!-- <div class="irs-teachers-social"> -->
                            <!-- <a href="#"><i class="zmdi zmdi-facebook"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-vimeo"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-pinterest"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-twitter"></i></a> -->
                        <!-- </div> -->
                    <!-- </div> -->
                <!-- </div> -->
                <!-- <div class="col-md-3 col-sm-6"> -->
                    <!-- <div class="irs-teachers-col animated fadeInUpShort slow delay-500"> -->
                        <!-- <a href="teacher-single.html"><img src="images/teachers/2.jpg" alt=""> -->
                        <!-- </a> -->
                        <!-- <div class="irs-teachers-name"> -->
                            <!-- <h4><a href="teacher-single.html">Ross Taylor</a></h4> -->
                            <!-- <p>english teacher</p> -->
                        <!-- </div> -->
                        <!-- <div class="irs-teachers-social"> -->
                            <!-- <a href="#"><i class="zmdi zmdi-facebook"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-vimeo"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-pinterest"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-twitter"></i></a> -->
                        <!-- </div> -->
                    <!-- </div> -->
                <!-- </div> -->
                <!-- <div class="col-md-3 col-sm-6"> -->
                    <!-- <div class="irs-teachers-col animated fadeInUpShort slow delay-750"> -->
                        <!-- <a href="teacher-single.html"><img src="images/teachers/3.jpg" alt=""> -->
                        <!-- </a> -->
                        <!-- <div class="irs-teachers-name"> -->
                            <!-- <h4><a href="teacher-single.html">Jessi Taylor</a></h4> -->
                            <!-- <p>chemistry teacher</p> -->
                        <!-- </div> -->
                        <!-- <div class="irs-teachers-social"> -->
                            <!-- <a href="#"><i class="zmdi zmdi-facebook"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-vimeo"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-pinterest"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-twitter"></i></a> -->
                        <!-- </div> -->
                    <!-- </div> -->
                <!-- </div> -->
                <!-- <div class="col-md-3 col-sm-6"> -->
                    <!-- <div class="irs-teachers-col animated fadeInUpShort slow delay-1000"> -->
                        <!-- <a href="teacher-single.html"><img src="images/teachers/4.jpg" alt=""> -->
                        <!-- </a> -->
                        <!-- <div class="irs-teachers-name"> -->
                            <!-- <h4><a href="teacher-single.html">Julio Jesus</a></h4> -->
                            <!-- <p>history teacher</p> -->
                        <!-- </div> -->
                        <!-- <div class="irs-teachers-social"> -->
                            <!-- <a href="#"><i class="zmdi zmdi-facebook"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-vimeo"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-pinterest"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-twitter"></i></a> -->
                        <!-- </div> -->
                    <!-- </div> -->
                <!-- </div> -->
                <!-- <div class="col-md-3 col-sm-6"> -->
                    <!-- <div class="irs-teachers-col animated fadeInUpShort slow delay-1250"> -->
                        <!-- <a href="teacher-single.html"><img src="images/teachers/5.jpg" alt=""> -->
                        <!-- </a> -->
                        <!-- <div class="irs-teachers-name"> -->
                            <!-- <h4><a href="teacher-single.html">ROSI JQULIN</a></h4> -->
                            <!-- <p>Math Teacher</p> -->
                        <!-- </div> -->
                        <!-- <div class="irs-teachers-social"> -->
                            <!-- <a href="#"><i class="zmdi zmdi-facebook"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-vimeo"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-pinterest"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-twitter"></i></a> -->
                        <!-- </div> -->
                    <!-- </div> -->
                <!-- </div> -->
                <!-- <div class="col-md-3 col-sm-6"> -->
                    <!-- <div class="irs-teachers-col animated fadeInUpShort slow delay-1500"> -->
                        <!-- <a href="teacher-single.html"><img src="images/teachers/6.jpg" alt=""> -->
                        <!-- </a> -->
                        <!-- <div class="irs-teachers-name"> -->
                            <!-- <h4><a href="teacher-single.html">ROSS TAYLOR</a></h4> -->
                            <!-- <p>English Teacher</p> -->
                        <!-- </div> -->
                        <!-- <div class="irs-teachers-social"> -->
                            <!-- <a href="#"><i class="zmdi zmdi-facebook"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-vimeo"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-pinterest"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-twitter"></i></a> -->
                        <!-- </div> -->
                    <!-- </div> -->
                <!-- </div> -->
                <!-- <div class="col-md-3 col-sm-6"> -->
                    <!-- <div class="irs-teachers-col animated fadeInUpShort slow delay-1750"> -->
                        <!-- <a href="teacher-single.html"><img src="images/teachers/7.jpg" alt=""> -->
                        <!-- </a> -->
                        <!-- <div class="irs-teachers-name"> -->
                            <!-- <h4><a href="teacher-single.html">JESSI TAYLOR</a></h4> -->
                            <!-- <p>Chemistry Teacher</p> -->
                        <!-- </div> -->
                        <!-- <div class="irs-teachers-social"> -->
                            <!-- <a href="#"><i class="zmdi zmdi-facebook"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-vimeo"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-pinterest"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-twitter"></i></a> -->
                        <!-- </div> -->
                    <!-- </div> -->
                <!-- </div> -->
                <!-- <div class="col-md-3 col-sm-6"> -->
                    <!-- <div class="irs-teachers-col animated fadeInUpShort slow delay-2000"> -->
                        <!-- <a href="teacher-single.html"><img src="images/teachers/8.jpg" alt=""> -->
                        <!-- </a> -->
                        <!-- <div class="irs-teachers-name"> -->
                            <!-- <h4><a href="teacher-single.html">Julio Jesus</a></h4> -->
                            <!-- <p>history teacher</p> -->
                        <!-- </div> -->
                        <!-- <div class="irs-teachers-social"> -->
                            <!-- <a href="#"><i class="zmdi zmdi-facebook"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-vimeo"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-pinterest"></i></a> -->
                            <!-- <a href="#"><i class="zmdi zmdi-twitter"></i></a> -->
                        <!-- </div> -->
                    <!-- </div> -->
                <!-- </div> -->
            <!-- </div> -->
            <!-- <div class="irs-pagination text-center"> -->
                <!-- <ul class="pagination"> -->
                    <!-- <li><a href="#">&lt;</a> -->
                    <!-- </li> -->
                    <!-- <li><a href="#">2</a> -->
                    <!-- </li> -->
                    <!-- <li><a href="#">3</a> -->
                    <!-- </li> -->
                    <!-- <li><a href="#">4</a> -->
                    <!-- </li> -->
                    <!-- <li><a href="#">&gt;</a> -->
                    <!-- </li> -->
                <!-- </ul> -->
            <!-- </div> -->
        <!-- </div> -->
    <!-- </section> -->
	<section class="irs-gallery-field mb-10">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="irs-section-title">
                        <!-- <h2>Awesome <span>gallery</span></h2> -->
                        <h2> <span>gallery</span></h2>
                        <div class="irs-title-line">
                            <div class="irs-title-icon">
                                <i class="icofont icofont-education"></i>
                            </div>
                        </div>
                        <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quam est dolorem quaerat harum sequi, nesciunt consequatur magni voluptatem similique </p> -->
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 col-sm-6 irs-col-padd-less">
                    <div class="irs-img-hover">
                        <img src="images/gallery/1.jpg" alt="">
                        <div class="irs-layer">
                            <a class="lightbox-image" href="images/gallery/1.jpg" data-fancybox-group="gallery" title="Gallery Photos">
                                <i class="zmdi zmdi-loupe"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 irs-col-padd-less">
                    <div class="irs-img-hover">
                        <img src="images/gallery/2.jpg" alt="">
                        <div class="irs-layer">
                            <a class="lightbox-image" href="images/gallery/2.jpg" data-fancybox-group="gallery" title="Gallery Photos">
                                <i class="zmdi zmdi-loupe"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 irs-col-padd-less">
                    <div class="irs-img-hover">
                        <img src="images/gallery/3.jpg" alt="">
                        <div class="irs-layer">
                            <a class="lightbox-image" href="images/gallery/3.jpg" data-fancybox-group="gallery" title="Gallery Photos">
                                <i class="zmdi zmdi-loupe"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 irs-col-padd-less">
                    <div class="irs-img-hover">
                        <img src="images/gallery/4.jpg" alt="">
                        <div class="irs-layer">
                            <a class="lightbox-image" href="images/gallery/4.jpg" data-fancybox-group="gallery" title="Gallery Photos">
                                <i class="zmdi zmdi-loupe"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-6 irs-col-padd-less">
                    <div class="irs-img-hover">
                        <img src="images/gallery/5.jpg" alt="">
                        <div class="irs-layer">
                            <a class="lightbox-image" href="images/gallery/5.jpg" data-fancybox-group="gallery" title="Gallery Photos">
                                <i class="zmdi zmdi-loupe"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 irs-col-padd-less">
                    <div class="irs-img-hover">
                        <img src="images/gallery/6.jpg" alt="">
                        <div class="irs-layer">
                            <a class="lightbox-image" href="images/gallery/6.jpg" data-fancybox-group="gallery" title="Gallery Photos">
                                <i class="zmdi zmdi-loupe"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 irs-col-padd-less">
                    <div class="irs-img-hover">
                        <img src="images/gallery/7.jpg" alt="">
                        <div class="irs-layer">
                            <a class="lightbox-image" href="images/gallery/7.jpg" data-fancybox-group="gallery" title="Gallery Photos">
                                <i class="zmdi zmdi-loupe"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 irs-col-padd-less">
                    <div class="irs-img-hover">
                        <img src="images/gallery/8.jpg" alt="">
                        <div class="irs-layer">
                            <a class="lightbox-image" href="images/gallery/8.jpg" data-fancybox-group="gallery" title="Gallery Photos">
                                <i class="zmdi zmdi-loupe"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Teachers  end -->

  @endsection