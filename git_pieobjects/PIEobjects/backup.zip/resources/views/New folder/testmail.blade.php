
Name: {{$name}}<br>
Email: {{$email}}<br>
Message: {{$subject}}

